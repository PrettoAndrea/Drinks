data class CocktailResponse(
    val drinks: List<Cocktail>?
)
