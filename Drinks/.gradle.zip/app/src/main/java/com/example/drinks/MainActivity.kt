@AndroidEntryPoint // se usi Hilt (facoltativo)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val repository = CocktailRepository(RetrofitInstance.api)
        val factory = CocktailViewModelFactory(repository)
        val viewModel = ViewModelProvider(this, factory)[CocktailViewModel::class.java]

        setContent {
            CocktailAppTheme {
                MainScreen(viewModel)
            }
        }
    }
}
