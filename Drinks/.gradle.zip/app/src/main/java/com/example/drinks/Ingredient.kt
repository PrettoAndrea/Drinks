package com.example.drinks

data class Ingridient(
    val ingredient: String?,
    val measure: String?
)
