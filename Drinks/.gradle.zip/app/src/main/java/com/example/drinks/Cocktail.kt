data class Cocktail(
    val strDrink: String?,
    val strDrinkThumb: String?,
    val strInstructions: String?
)
